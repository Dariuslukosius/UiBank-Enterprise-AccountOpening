
import sys
import parabank_api_client
import json
from urllib import request, error, parse



def main(username=None, password=None, loanAmount=None, argv=None):
    # Allow passing credentials and loan amount directly, or via argv fallback
    argv = argv or sys.argv[1:]
    # argv fallback order: username password loanAmount
    if username is None and len(argv) >= 1:
        username = argv[0]
    if password is None and len(argv) >= 2:
        password = argv[1]
    if loanAmount is None and len(argv) >= 3:
        try:
            loanAmount = float(argv[2])
        except Exception:
            loanAmount = None

    api_client = parabank_api_client.ParabankAPI()

    # helper to format error messages combining error and body
    def _fmt_err(resp):
        if not isinstance(resp, dict):
            return str(resp)
        parts = []
        if resp.get('error'):
            parts.append(str(resp.get('error')))
        if resp.get('body'):
            parts.append(str(resp.get('body')))
        if parts:
            return ', '.join(parts)
        return None

    # prepare unified response object used across calls
    resp_obj = {
        'error': None,
        'step': None,
        'customerId': None,
        'loadGiven': False,
        'loanAmount': loanAmount,
    }

    # early exit if error already present
    if resp_obj.get('error'):
        return json.dumps(resp_obj)

    # login
    res = api_client.login(username, password)
    print("login ->", res)
    resp_obj['customerId'] = api_client.customer_id
    if not res.get('ok'):
        resp_obj['error'] = _fmt_err(res) or 'login failed'
        resp_obj['step'] = 'login'
        return json.dumps(resp_obj)

    # get accounts
    acct_res = api_client.get_accounts()
    if not acct_res.get('ok'):
        resp_obj['error'] = _fmt_err(acct_res) or 'get_accounts failed'
        resp_obj['step'] = 'get_accounts'
        return json.dumps(resp_obj)
    print("get_accounts ->", acct_res)

    # If loanAmount provided, find an account with balance >= 20% of loanAmount
    sufficient_acct = None
    threshold = None
    if loanAmount is not None:
        try:
            threshold = float(loanAmount) * 0.2
        except Exception:
            threshold = None

        if threshold is not None:
            for acct in acct_res.get('data', []):
                # attempt to parse balance; support numeric or string values
                bal = acct.get('balance') if isinstance(acct, dict) else None
                try:
                    bal_num = float(bal)
                except Exception:
                    # skip entries with non-numeric balance
                    continue
                if bal_num >= threshold:
                    sufficient_acct = acct
                    break

    if loanAmount is None:
        print("loanAmount not provided; skipping account selection")
    elif sufficient_acct is None:
        resp_obj['error'] = 'no account meets collateral threshold'
        resp_obj['step'] = 'select_collateral'
        return json.dumps(resp_obj)
    else:
        print("Selected account for collateral ->", sufficient_acct)

    # Optionally create an account and request a loan if loanAmount provided
    if resp_obj.get('error'):
        return json.dumps(resp_obj)

    new_account = api_client.create_account(0, sufficient_acct['id'])
    if not new_account.get('ok'):
        resp_obj['error'] = _fmt_err(new_account) or 'create_account failed'
        resp_obj['step'] = 'create_account'
        return json.dumps(resp_obj)
    print("create_account ->", new_account)

    if loanAmount is not None:
        print(new_account['data']['balance'] < threshold, new_account['data'], threshold)
        if new_account['data']['balance'] < threshold:
            if resp_obj.get('error'):
                return json.dumps(resp_obj)
            transfer_for_loan_res = api_client.transfer_for_loan(sufficient_acct['id'], new_account['data']['id'], threshold - 100)
            if not transfer_for_loan_res.get('ok'):
                resp_obj['error'] = _fmt_err(transfer_for_loan_res) or 'transfer_for_loan failed'
                resp_obj['step'] = 'transfer_for_loan'
                return json.dumps(resp_obj)
        if resp_obj.get('error'):
            return json.dumps(resp_obj)
        loan_request_res = api_client.request_loan(new_account['data']['id'], loanAmount)
        if not loan_request_res.get('ok'):
            resp_obj['error'] = _fmt_err(loan_request_res) or 'request_loan failed'
            resp_obj['step'] = 'request_loan'
            return json.dumps(resp_obj)
        # mark loan given
        resp_obj['loadGiven'] = True
        resp_obj['loanAmount'] = loanAmount
        if resp_obj.get('error'):
            return json.dumps(resp_obj)
        get_transactions_res = api_client.get_transactions(sufficient_acct['id'])
        if not get_transactions_res.get('ok'):
            resp_obj['error'] = _fmt_err(get_transactions_res) or 'get_transactions failed'
            resp_obj['step'] = 'get_transactions'
            return json.dumps(resp_obj)
        print("get_transactions ->", get_transactions_res)

    # final return of structured response (JSON string)
    return json.dumps(resp_obj)


if __name__ == "__main__":
    raise SystemExit(main())