"""Clean Parabank API client implementation.

This client stores session information after login:
- `self.customer_id` set from the response body when available
- `self.jsessionid` extracted from Set-Cookie and attached to future requests

It also requests JSON responses by default and declares Content-Type.
"""
from urllib import request, error, parse
import json
import re


class ParabankAPI:
    BASE_URL = "https://parabank.parasoft.com/parabank/services/bank"

    def __init__(self):
        self.customer_id = None
        self.jsessionid = None

    def logout(self):
        """Clear session information."""
        self.customer_id = None
        self.jsessionid = None

    def _attach_session_cookie(self, req: request.Request):
        if self.jsessionid:
            req.add_header('Cookie', f'JSESSIONID={self.jsessionid}')

    def _parse_body(self, raw_bytes: bytes):
        text = raw_bytes.decode('utf-8', errors='replace')
        try:
            return json.loads(text)
        except Exception:
            return text

    def _extract_jsessionid(self, resp):
        try:
            set_cookie = None
            if hasattr(resp, 'getheader'):
                set_cookie = resp.getheader('Set-Cookie')
            if not set_cookie and hasattr(resp, 'headers'):
                set_cookie = resp.headers.get('Set-Cookie')
            if set_cookie:
                m = re.search(r"JSESSIONID=([^;]+)", set_cookie)
                if m:
                    return m.group(1)
        except Exception:
            pass
        return None

    def _extract_customer_id(self, data):
        try:
            if isinstance(data, dict):
                cid = data.get('customerId') or data.get('id')
                if cid is not None:
                    return cid
            elif isinstance(data, str):
                m = re.search(r"<id>(\d+)</id>", data)
                if m:
                    return int(m.group(1))
        except Exception:
            pass
        return None

    def _do_request(self, req: request.Request, timeout: int = 10, capture_cookie: bool = False) -> dict:
        """Unified request executor that handles response parsing and HTTP errors.

        Returns a dict matching existing return shape: keys like ok, status, data, error, body.
        If capture_cookie is True and the response contains a JSESSIONID, it will be stored on
        self.jsessionid.
        """
        try:
            with request.urlopen(req, timeout=timeout) as resp:
                status = resp.getcode()
                raw = resp.read()
                data = self._parse_body(raw)

                if capture_cookie:
                    jsid = self._extract_jsessionid(resp)
                    if jsid:
                        self.jsessionid = jsid

                return {"ok": status == 200, "status": status, "data": data}

        except error.HTTPError as he:
            body = None
            try:
                body = he.read().decode('utf-8', errors='replace')
            except Exception:
                body = None
            return {"ok": False, "status": getattr(he, 'code', None), "error": str(he), "body": body}
        except error.URLError as ue:
            return {"ok": False, "error": str(ue)}

    def login(self, username: str, password: str, timeout: int = 10) -> dict:
        if username is None:
            username = ""
        if password is None:
            password = ""

        safe_user = parse.quote(str(username), safe='')
        safe_pass = parse.quote(str(password), safe='')
        url = f"{self.BASE_URL}/login/{safe_user}/{safe_pass}"
        print('url ->', url, safe_user, safe_pass)

        req = request.Request(url, method="GET")
        # Request JSON responses and declare the content type
        req.add_header("Accept", "application/json")
        req.add_header("Content-Type", "application/json")
        # attach cookie if we already have a session
        self._attach_session_cookie(req)

        res = self._do_request(req, timeout=timeout, capture_cookie=True)

        # try to set customer_id when possible
        if res.get('ok') and 'data' in res:
            cid = self._extract_customer_id(res.get('data'))
            if cid is not None:
                self.customer_id = cid

        return res

    def get_accounts(self, customer_id: int = None, timeout: int = 10) -> dict:
        """Retrieve accounts for a customer.

        If customer_id is not provided, uses self.customer_id. Attaches session
        cookie if available. Returns dict with keys: ok, status, data or error.
        """
        cid = customer_id if customer_id is not None else self.customer_id
        if cid is None:
            return {"ok": False, "error": "missing customer_id"}

        url = f"{self.BASE_URL}/customers/{cid}/accounts"
        req = request.Request(url, method="GET")
        req.add_header("Accept", "application/json")
        req.add_header("Content-Type", "application/json")
        self._attach_session_cookie(req)

        return self._do_request(req, timeout=timeout)

    def get_transactions(self, account_id: int, timeout: int = 10) -> dict:
        """Retrieve transactions for a given account id.

        Calls GET /accounts/{account_id}/transactions and returns the unified response.
        """
        if account_id is None:
            return {"ok": False, "error": "missing account_id"}

        url = f"{self.BASE_URL}/accounts/{account_id}/transactions"
        req = request.Request(url, method="GET")
        req.add_header("Accept", "application/json")
        req.add_header("Content-Type", "application/json")
        self._attach_session_cookie(req)

        return self._do_request(req, timeout=timeout)

    def create_account(self, account_type: int, from_account_id: int = None, customer_id: int = None, timeout: int = 10) -> dict:
        """Create a new account for a customer.

        Builds a POST to /createAccount with query parameters:
        - customerId
        - newAccountType
        - fromAccountId

        If from_account_id is not provided, the method will call get_accounts
        and use the first account id as the fromAccountId.
        """
        cid = customer_id if customer_id is not None else self.customer_id
        if cid is None:
            return {"ok": False, "error": "missing customer_id"}

        # determine from_account_id if not provided
        fa = from_account_id
        if fa is None:
            acct_res = self.get_accounts(customer_id=cid, timeout=timeout)
            if not acct_res.get('ok') or not isinstance(acct_res.get('data'), list) or len(acct_res['data']) == 0:
                return {"ok": False, "error": "no fromAccount available"}
            first = acct_res['data'][0]
            fa = first.get('id') if isinstance(first, dict) else None
            if fa is None:
                return {"ok": False, "error": "no fromAccount id"}

        params = {
            'customerId': cid,
            'newAccountType': account_type,
            'fromAccountId': fa,
        }
        query = parse.urlencode(params)
        url = f"{self.BASE_URL}/createAccount?{query}"

        # ensure POST by providing empty bytes
        req = request.Request(url, data=b'', method="POST")
        req.add_header("Accept", "application/json")
        req.add_header("Content-Type", "application/json")
        self._attach_session_cookie(req)

        return self._do_request(req, timeout=timeout, capture_cookie=True)

    def request_loan(self, from_account_id: int, amount: int = 10000, customer_id: int = None, timeout: int = 10) -> dict:
        """Request a loan for a customer.

        Builds a POST to /requestLoan with query parameters:
        - customerId
        - amount
        - downPayment (20% of amount)
        - fromAccountId

        The method resolves customer_id from self.customer_id if not provided.
        """
        cid = customer_id if customer_id is not None else self.customer_id
        if cid is None:
            return {"ok": False, "error": "missing customer_id"}

        fa = from_account_id
        if fa is None:
            acct_res = self.get_accounts(customer_id=cid, timeout=timeout)
            if not acct_res.get('ok') or not isinstance(acct_res.get('data'), list) or len(acct_res['data']) == 0:
                return {"ok": False, "error": "no fromAccount available"}
            first = acct_res['data'][0]
            fa = first.get('id') if isinstance(first, dict) else None
            if fa is None:
                return {"ok": False, "error": "no fromAccount id"}

        # compute downPayment as 20% of amount (rounded to nearest integer)
        down_payment = int(round(amount * 0.20))

        params = {
            'customerId': cid,
            'amount': amount,
            'downPayment': down_payment,
            'fromAccountId': fa,
        }
        query = parse.urlencode(params)
        url = f"{self.BASE_URL}/requestLoan?{query}"

        # POST with empty body to ensure method is POST
        req = request.Request(url, data=b'', method="POST")
        req.add_header("Accept", "application/json")
        req.add_header("Content-Type", "application/json")
        self._attach_session_cookie(req)

        return self._do_request(req, timeout=timeout)

    def transfer_for_loan(self, from_account_id: int, to_account_id: int, loan_amount: float, timeout: int = 10) -> dict:
        """Transfer funds to cover part of the down payment for a loan.

        Builds a POST to /transfer with query parameters:
        - fromAccountId
        - toAccountId
        - amount (computed as round(loan_amount * 0.2) - 100)

        Returns the unified response dict from _do_request.
        """
        if from_account_id is None:
            return {"ok": False, "error": "missing from_account_id"}
        if to_account_id is None:
            return {"ok": False, "error": "missing to_account_id"}
        try:
            amt = int(round(float(loan_amount) * 0.20)) - 100
        except Exception:
            return {"ok": False, "error": "invalid loan_amount"}

        # ensure amt is non-negative
        if amt < 0:
            amt = 0

        params = {
            'fromAccountId': from_account_id,
            'toAccountId': to_account_id,
            'amount': amt,
        }
        query = parse.urlencode(params)
        url = f"{self.BASE_URL}/transfer?{query}"

        req = request.Request(url, data=b'', method="POST")
        req.add_header("Accept", "application/json")
        req.add_header("Content-Type", "application/json")
        self._attach_session_cookie(req)

        return self._do_request(req, timeout=timeout)
